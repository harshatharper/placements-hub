========================================================
  HARPER REMARKET — Chrome Extension Setup Guide
========================================================

This Chrome extension lets you submit remarket requests
directly from any Big Brother company page. The request
will appear on the Placements Dashboard for the team
to pick up and action.


WHAT IT DOES
------------
- Detects when you're on a Big Brother company page
  (e.g. harper.up.railway.app/company/12345)
- Auto-fills the company name, industry, and state
- Lets you select coverage lines, reason, priority,
  and optional notes
- Submits a remarket request that shows up on the
  Placements Dashboard > Remarket Requests tab


SETUP INSTRUCTIONS (5 minutes)
-------------------------------

Step 1: Unzip this file
   - You should see this README and a folder called
     "placements-chrome-extension" containing the
     extension files (manifest.json, popup.html, etc.)

Step 2: Open Chrome Extensions page
   - Open Google Chrome
   - Type  chrome://extensions  in the address bar
     and press Enter
   - OR: click the three-dot menu (top-right) >
     Extensions > Manage Extensions

Step 3: Enable Developer Mode
   - In the top-right corner of the Extensions page,
     you'll see a toggle labeled "Developer mode"
   - Turn it ON (slide it to the right)
   - The page will expand to show extra buttons

Step 4: Load the extension
   - Click the "Load unpacked" button (top-left area)
   - A file picker will open
   - Navigate to and select the
     "placements-chrome-extension" folder
     (the folder itself, NOT individual files inside it)
   - Click "Select" / "Open"

Step 5: Pin the extension (recommended)
   - Click the puzzle piece icon in Chrome's toolbar
     (top-right, next to the address bar)
   - Find "Harper Remarket" in the list
   - Click the pin icon next to it so it stays visible
     in your toolbar

Step 6: You're done!
   - Navigate to any Big Brother company page
   - Click the Harper Remarket icon in your toolbar
   - The company info will auto-populate
   - Fill in the form and hit Send


HOW TO USE
----------

1. Go to a company page on Big Brother
   (harper.up.railway.app/company/XXXXX)

2. Click the Harper Remarket extension icon
   in your Chrome toolbar

3. The extension will automatically detect the
   company and show you the remarket form

4. Fill in:
   - Your Name: enter your name (saved for next time)
   - Coverage Lines: click one or more coverage types
   - Reason: select why you're requesting a remarket
   - Priority: Normal or Urgent
   - Notes: any additional context (optional)

5. Click "Send Remarket Request"

6. Done! The request will appear on the Placements
   Dashboard under the "Remarket Requests" tab


TROUBLESHOOTING
---------------

"Navigate to a Big Brother company page"
   You're not on a company page. Make sure the URL
   looks like: harper.up.railway.app/company/12345

"Something went wrong"
   The extension couldn't connect to the database.
   Check your internet connection and try again.
   If the problem persists, reach out in the
   #placements Slack channel.

Extension not showing in toolbar?
   Go to chrome://extensions and make sure
   "Harper Remarket" is enabled. Then click the
   puzzle piece icon and pin it.

Chrome says "Disable developer mode extensions"?
   This is normal for unpacked extensions. Just click
   the X to dismiss — the extension will keep working.


UPDATING THE EXTENSION
-----------------------
When a new version is shared:
1. Unzip the new file
2. Replace the old "placements-chrome-extension" folder
   with the new one (same location on your computer)
3. Go to chrome://extensions
4. Click the refresh icon on the Harper Remarket card
5. Done — you're on the latest version


QUESTIONS?
----------
Drop a message in #placements on Slack.

========================================================
