// Supabase config
const SUPABASE_URL = 'https://ehvopzzidrfxtvsfrfkq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVodm9wenppZHJmeHR2c2ZyZmtxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA5OTMzNDksImV4cCI6MjA2NjU2OTM0OX0.4ujQFyFGuCUAZ8PJGpNTD5MiUOUo8yeg0l_AzlomySs';

const BIG_BROTHER_PATTERN = /^https:\/\/harper\.up\.railway\.app\/company\/(\d+)/;

const COVERAGE_OPTIONS = [
  'GL', 'PL', 'WC', 'UMB', 'CA', 'CP',
  'BOP', 'IM', 'CYBER', 'DO', 'EPLI', 'HIRED',
  'PROD', 'LL', 'GAR', 'PROP', 'SURETY', 'OTHER'
];

// State
let companyId = null;
let selectedCoverages = new Set();
let priority = 'normal';

// DOM elements
const notOnPage = document.getElementById('not-on-page');
const loadingState = document.getElementById('loading');
const errorState = document.getElementById('error-state');
const formContainer = document.getElementById('form-container');
const successState = document.getElementById('success');

// Supabase helpers
function supabaseFetch(path, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const headers = {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
    // Supabase project uses a non-default schema — explicitly target "public"
    'Accept-Profile': 'public',
    ...(method === 'POST' || method === 'PATCH' ? { 'Content-Profile': 'public' } : {}),
    ...options.headers,
  };
  return fetch(`${SUPABASE_URL}${path}`, { ...options, headers });
}

// Show/hide states
function showState(el) {
  [notOnPage, loadingState, errorState, formContainer, successState].forEach(s => s.style.display = 'none');
  el.style.display = el === formContainer ? 'block' : 'flex';
}

// Build coverage grid
function buildCoverageGrid() {
  const grid = document.getElementById('coverage-grid');
  COVERAGE_OPTIONS.forEach(code => {
    const chip = document.createElement('div');
    chip.className = 'coverage-chip';
    chip.textContent = code;
    chip.addEventListener('click', () => {
      if (selectedCoverages.has(code)) {
        selectedCoverages.delete(code);
        chip.classList.remove('selected');
      } else {
        selectedCoverages.add(code);
        chip.classList.add('selected');
      }
      validateForm();
    });
    grid.appendChild(chip);
  });
}

// Priority toggle
function setupPriorityToggle() {
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.priority-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      priority = btn.dataset.value;
    });
  });
}

// Form validation
function validateForm() {
  const name = document.getElementById('requested-by').value.trim();
  const reason = document.getElementById('reason').value;
  const hasCoverage = selectedCoverages.size > 0;
  document.getElementById('submit-btn').disabled = !(name && reason && hasCoverage);
}

// Restore saved name
function restoreName() {
  chrome.storage.local.get(['requestedBy'], (result) => {
    if (result.requestedBy) {
      document.getElementById('requested-by').value = result.requestedBy;
      validateForm();
    }
  });
}

// Save name
function saveName(name) {
  chrome.storage.local.set({ requestedBy: name });
}

// Fetch company from Supabase
async function fetchCompany(id) {
  const res = await supabaseFetch(`/rest/v1/companies?id=eq.${id}&select=id,company_name,company_industry,company_state`);
  if (!res.ok) throw new Error('Failed to fetch company');
  const data = await res.json();
  if (!data.length) throw new Error('Company not found');
  return data[0];
}

// Submit remarket request
async function submitRequest(payload) {
  const res = await supabaseFetch('/rest/v1/placement_remarket_requests', {
    method: 'POST',
    headers: { 'Prefer': 'return=minimal' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err || 'Failed to submit');
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  buildCoverageGrid();
  setupPriorityToggle();

  // Listen for form changes
  document.getElementById('requested-by').addEventListener('input', validateForm);
  document.getElementById('reason').addEventListener('change', validateForm);

  // Form submission
  document.getElementById('remarket-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = document.getElementById('submit-btn');
    const submitText = document.getElementById('submit-text');
    const submitLoading = document.getElementById('submit-loading');

    submitBtn.disabled = true;
    submitText.style.display = 'none';
    submitLoading.style.display = 'inline';

    const name = document.getElementById('requested-by').value.trim();
    saveName(name);

    try {
      await submitRequest({
        company_id: companyId,
        requested_by: name,
        coverage_codes: Array.from(selectedCoverages),
        reason: document.getElementById('reason').value,
        priority: priority,
        notes: document.getElementById('notes').value.trim() || null,
      });
      showState(successState);
    } catch (err) {
      submitBtn.disabled = false;
      submitText.style.display = 'inline';
      submitLoading.style.display = 'none';
      alert('Failed to submit: ' + err.message);
    }
  });

  // New request button
  document.getElementById('new-request-btn').addEventListener('click', () => {
    // Reset form
    selectedCoverages.clear();
    document.querySelectorAll('.coverage-chip').forEach(c => c.classList.remove('selected'));
    document.getElementById('reason').value = '';
    document.getElementById('notes').value = '';
    priority = 'normal';
    document.querySelectorAll('.priority-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.priority-btn[data-value="normal"]').classList.add('active');
    document.getElementById('submit-btn').disabled = true;
    document.getElementById('submit-text').style.display = 'inline';
    document.getElementById('submit-loading').style.display = 'none';
    showState(formContainer);
  });

  // Detect company page
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const url = tabs[0]?.url;
    const match = url?.match(BIG_BROTHER_PATTERN);

    if (!match) {
      showState(notOnPage);
      return;
    }

    companyId = parseInt(match[1], 10);
    showState(loadingState);

    try {
      const company = await fetchCompany(companyId);
      document.getElementById('company-name').textContent = company.company_name;
      document.getElementById('company-industry').textContent = company.company_industry || '';
      document.getElementById('company-state').textContent = company.company_state || '';
      restoreName();
      showState(formContainer);
    } catch (err) {
      document.getElementById('error-msg').textContent = err.message;
      showState(errorState);
    }
  });
});
